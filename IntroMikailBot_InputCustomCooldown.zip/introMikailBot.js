
const {
    makeWASocket,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    Browsers,
    delay,
    DisconnectReason
} = require('@whiskeysockets/baileys')
const readline = require('readline')

function prompt(query) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })
    return new Promise(resolve => rl.question(query, ans => {
        rl.close()
        resolve(ans)
    }))
}

let globalCooldown = 5000
let globalPhone = ''

async function connectBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info_mikail')
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        version,
        auth: state,
        browser: Browsers.macOS('Intro Bot Mikail')
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update

        if (connection === 'connecting' && !sock.authState.creds.registered) {
            try {
                globalPhone = await prompt('📱 Masukkan nomor WhatsApp kamu (contoh: 628xxxxx): ')
                const inputCooldown = await prompt('⏱️ Masukkan jeda antar pesan dalam milidetik (misal 5000 untuk 5 detik): ')
                globalCooldown = parseInt(inputCooldown) || 5000
                const code = await sock.requestPairingCode(globalPhone)
                console.log(`📟 Pairing Code untuk ${globalPhone}: ${code}`)
            } catch (err) {
                console.error('❌ Gagal pairing:', err)
            }
        }

        if (connection === 'open') {
            console.log('✅ Terhubung ke WhatsApp!')
            await kirimPerkenalan(sock)
        } else if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode
            if (code !== DisconnectReason.loggedOut) {
                console.log('🔁 Mencoba konek ulang...')
                connectBot()
            } else {
                console.log('❌ Logout. Silakan pairing ulang.')
            }
        }
    })
}

async function kirimPerkenalan(sock) {
    const contacts = await sock.getContacts()
    const pesan = `📩 *Assalamualaikum Wr. Wb.*

Ini *Mikail* — saya menggunakan *nomor baru* karena akun WhatsApp lama saya:
❗ *Telah dihack*
❌ *Diblokir oleh WhatsApp*

Mohon hati-hati: Jika ada yang *mengatasnamakan Mikail* dari nomor lain, itu *BUKAN saya.*

📲 Tolong simpan nomor ini. Terima kasih banyak atas pengertiannya.
🙏`

    console.log(`📬 Mengirim pesan ke ${contacts.length} kontak dengan jeda ${globalCooldown / 1000} detik...`)

    for (const contact of contacts) {
        try {
            const id = contact.id.replace('@s.whatsapp.net', '')
            if (contact.id.endsWith('@s.whatsapp.net') && id !== '62') {
                await sock.sendMessage(contact.id, { text: pesan })
                console.log(`✅ Terkirim ke ${contact.id}`)
                await delay(globalCooldown)
            }
        } catch (err) {
            console.log(`⚠️ Gagal ke ${contact.id}: ${err.message}`)
        }
    }

    console.log('🎉 Semua pesan selesai dikirim.')
}

connectBot()
