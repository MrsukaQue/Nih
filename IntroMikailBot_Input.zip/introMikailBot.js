
const {
    makeWASocket,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    Browsers,
    delay,
    DisconnectReason
} = require('@whiskeysockets/baileys')
const readline = require('readline')

// Prompt function to get input from user
function prompt(query) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })
    return new Promise(resolve => rl.question(query, ans => {
        rl.close()
        resolve(ans)
    }))
}

async function connectBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./auth_info_mikail')
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        version,
        auth: state,
        browser: Browsers.macOS('Intro Bot Mikail')
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update

        if (connection === 'connecting' && !sock.authState.creds.registered) {
            try {
                const phoneNumber = await prompt('📱 Masukkan nomor WhatsApp kamu (contoh: 628xxxxx): ')
                const code = await sock.requestPairingCode(phoneNumber)
                console.log(`📟 Pairing Code untuk ${phoneNumber}: ${code}`)
            } catch (err) {
                console.error('❌ Gagal mendapatkan pairing code:', err)
            }
        }

        if (connection === 'open') {
            console.log('✅ Terhubung ke WhatsApp!')
            await kirimPerkenalan(sock)
        } else if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode
            if (code !== DisconnectReason.loggedOut) {
                console.log('🔁 Mencoba konek ulang...')
                connectBot()
            } else {
                console.log('❌ Logout. Silakan pairing ulang.')
            }
        }
    })
}

async function kirimPerkenalan(sock) {
    const cooldown = 5000 // 5 detik
    const contacts = await sock.getContacts()

    const pesan = `📩 *Assalamualaikum Wr. Wb.*

Ini *Mikail* — saya menggunakan *nomor baru* karena akun WhatsApp lama saya:
❗ *Telah dihack*
❌ *Diblokir oleh WhatsApp*

Mohon hati-hati: Jika ada yang *mengatasnamakan Mikail* dari nomor lain, itu *BUKAN saya.*

📲 Tolong simpan nomor ini. Terima kasih banyak atas pengertiannya.
🙏`

    console.log(`📬 Mengirim pesan ke ${contacts.length} kontak dengan jeda ${cooldown / 1000} detik...`)

    for (const contact of contacts) {
        try {
            const id = contact.id.replace('@s.whatsapp.net', '')
            if (contact.id.endsWith('@s.whatsapp.net') && id !== '62') {
                await sock.sendMessage(contact.id, { text: pesan })
                console.log(`✅ Terkirim ke ${contact.id}`)
                await delay(cooldown)
            }
        } catch (err) {
            console.log(`⚠️ Gagal ke ${contact.id}: ${err.message}`)
        }
    }

    console.log('🎉 Semua pesan selesai dikirim.')
}

connectBot()
